# CNotes_v1.0

CNotes is a software solution for contemporaneous note taking. The notes and information generated through the use of the sofware is stored in an encrypted database (LiteDB) and is developed using C#'s Windows Forms. 

# Disclaimer

CNotes was developed in partial fulfilment of the requirements of the bachelors degree in digital forensics at Noroff UC. It should not be used for production work, this is an early release application.

# Installation Guide

The installation package is in the folder "Installation Package". Download the entire folder and run either the .exe or the .msi file. The User Guide is included in the installation package

# Feedback

Don't hesitate to contact me directly on Twitter if you have feedback, as well as on here if you encounter issues.
